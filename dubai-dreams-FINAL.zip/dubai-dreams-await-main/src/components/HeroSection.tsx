import { motion } from "framer-motion";
import { Phone } from "lucide-react";
const HeroSection = () => {
  return <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Video Background */}
      <div className="absolute inset-0 z-0">
        {/* Loading skeleton */}
        <div className="absolute inset-0 bg-charcoal-deep animate-pulse" id="hero-skeleton" />
        <video
        autoPlay
        muted
        loop
        playsInline
        className="w-full h-full object-cover"
        onLoadedData={(e) => {
          const skeleton = document.getElementById('hero-skeleton');
          if (skeleton) skeleton.style.display = 'none';
          (e.target as HTMLVideoElement).style.opacity = '1';
        }}
        style={{ opacity: 0, transition: 'opacity 0.8s ease' }}>

          <source src="/dubai-hero.mp4" type="video/mp4" />
        </video>
        {/* Overlay */}
        <div className="absolute inset-0" style={{
        background: "var(--gradient-hero-overlay)"
      }} />
      </div>

      {/* Content */}
      <div className="relative z-10 text-center px-6 max-w-5xl mx-auto">
        <motion.p initial={{
        opacity: 0,
        y: 20
      }} animate={{
        opacity: 1,
        y: 0
      }} transition={{
        duration: 0.8,
        delay: 0.2
      }} className="font-body text-gold-light uppercase tracking-[0.3em] text-sm md:text-base mb-6">
          Mauritius → Dubai
        </motion.p>

        <motion.h1 initial={{
        opacity: 0,
        y: 30
      }} animate={{
        opacity: 1,
        y: 0
      }} transition={{
        duration: 1,
        delay: 0.4
      }} className="font-display text-5xl md:text-7xl lg:text-8xl text-foreground leading-tight mb-6">
          Dubai <span className="text-gradient-gold italic">Experience</span>
        </motion.h1>

        <motion.div initial={{
        opacity: 0,
        scaleX: 0
      }} animate={{
        opacity: 1,
        scaleX: 1
      }} transition={{
        duration: 0.8,
        delay: 0.8
      }} className="divider-gold max-w-xs mx-auto mb-8" />

        <motion.p initial={{
        opacity: 0,
        y: 20
      }} animate={{
        opacity: 1,
        y: 0
      }} transition={{
        duration: 0.8,
        delay: 1
      }} className="font-body text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto mb-4">
          6 Days · 5 Nights
        </motion.p>

        <motion.p initial={{
        opacity: 0,
        y: 20
      }} animate={{
        opacity: 1,
        y: 0
      }} transition={{
        duration: 0.8,
        delay: 1.2
      }} className="font-display text-3xl md:text-4xl text-gradient-gold mb-10">
          Rs 95,000 <span className="text-lg text-muted-foreground font-body">/ person</span>
        </motion.p>

        <motion.a href="https://wa.me/23054960101" target="_blank" rel="noopener noreferrer" initial={{
        opacity: 0,
        y: 20
      }} animate={{
        opacity: 1,
        y: 0
      }} transition={{
        duration: 0.8,
        delay: 1.4
      }} whileHover={{
        scale: 1.02
      }} whileTap={{
        scale: 0.98
      }} className="inline-flex items-center gap-3 bg-gradient-gold text-primary-foreground px-8 py-4 rounded-full font-body font-semibold text-lg shadow-gold hover:shadow-elegant transition-all duration-300">
          <Phone className="w-5 h-5" />
          Reserve Your Seat
        </motion.a>
      </div>

      {/* Scroll Indicator */}
      <motion.div initial={{
      opacity: 0
    }} animate={{
      opacity: 1
    }} transition={{
      delay: 2
    }} className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10">
        
      </motion.div>
    </section>;
};
export default HeroSection;