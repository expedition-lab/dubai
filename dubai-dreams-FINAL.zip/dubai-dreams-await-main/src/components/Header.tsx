import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Phone, Menu, X } from "lucide-react";
import { useSmoothScroll } from "@/hooks/useSmoothScroll";

const navItems = [
  { label: "Highlights", target: "highlights" },
  { label: "Itinerary", target: "itinerary" },
  { label: "Inclusions", target: "inclusions" },
  { label: "Pricing", target: "pricing" },
];

const Header = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState<string>("");
  const { handleClick } = useSmoothScroll({ offset: 100, duration: 800 });

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);

      // Determine active section based on scroll position
      const sections = navItems.map((item) => document.getElementById(item.target));
      const scrollPosition = window.scrollY + 150;

      for (let i = sections.length - 1; i >= 0; i--) {
        const section = sections[i];
        if (section && section.offsetTop <= scrollPosition) {
          setActiveSection(navItems[i].target);
          break;
        }
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, target: string) => {
    handleClick(e, target);
    setIsMobileMenuOpen(false);
  };

  const scrollToTop = (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault();
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <motion.header
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.8, delay: 0.5 }}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        isScrolled ? "glass-dark py-4" : "bg-transparent py-6"
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
        {/* Logo */}
        <a 
          href="#" 
          onClick={scrollToTop}
          className="flex items-center gap-3 group"
        >
          <div className="w-10 h-10 rounded-xl bg-gradient-gold flex items-center justify-center shadow-gold group-hover:shadow-elegant transition-shadow duration-300">
            <span className="font-display text-primary-foreground text-lg font-bold">B</span>
          </div>
          <span className="font-display text-xl text-foreground hidden sm:block group-hover:text-gold transition-colors duration-300">
            BlueXpedition
          </span>
        </a>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-1">
          {navItems.map((item) => (
            <a
              key={item.target}
              href={`#${item.target}`}
              onClick={(e) => handleNavClick(e, item.target)}
              className={`relative font-body px-4 py-2 rounded-full transition-all duration-300 ${
                activeSection === item.target
                  ? "text-gold"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {item.label}
              {/* Active indicator */}
              <motion.span
                initial={false}
                animate={{
                  opacity: activeSection === item.target ? 1 : 0,
                  scale: activeSection === item.target ? 1 : 0.8,
                }}
                transition={{ duration: 0.3 }}
                className="absolute bottom-0 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full bg-gold"
              />
            </a>
          ))}
        </nav>

        {/* CTA */}
        <div className="flex items-center gap-4">
          <motion.a
            href="https://wa.me/23054960101"
            target="_blank"
            rel="noopener noreferrer"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className="inline-flex items-center gap-2 bg-gradient-gold text-primary-foreground px-5 py-2.5 rounded-full font-body font-medium text-sm shadow-gold hover:shadow-elegant transition-all duration-300"
          >
            <Phone className="w-4 h-4" />
            Book Now
          </motion.a>

          {/* Mobile Menu Toggle */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="md:hidden p-2 text-foreground hover:text-gold transition-colors"
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <motion.div
        initial={false}
        animate={{
          opacity: isMobileMenuOpen ? 1 : 0,
          y: isMobileMenuOpen ? 0 : -20,
          pointerEvents: isMobileMenuOpen ? "auto" : "none",
        }}
        transition={{ duration: 0.3, ease: "easeOut" }}
        className="md:hidden glass-dark mt-4 mx-6 rounded-2xl p-6 absolute left-0 right-0"
      >
        <nav className="flex flex-col gap-2">
          {navItems.map((item, index) => (
            <motion.a
              key={item.target}
              href={`#${item.target}`}
              onClick={(e) => handleNavClick(e, item.target)}
              initial={{ opacity: 0, x: -10 }}
              animate={{
                opacity: isMobileMenuOpen ? 1 : 0,
                x: isMobileMenuOpen ? 0 : -10,
              }}
              transition={{ delay: index * 0.05, duration: 0.2 }}
              className={`font-body py-3 px-4 rounded-xl transition-colors duration-200 ${
                activeSection === item.target
                  ? "text-gold bg-gold/10"
                  : "text-foreground hover:bg-muted/50"
              }`}
            >
              {item.label}
            </motion.a>
          ))}
          <div className="divider-gold my-3" />
          <motion.a
            href="https://wa.me/23054960101"
            target="_blank"
            rel="noopener noreferrer"
            initial={{ opacity: 0, x: -10 }}
            animate={{
              opacity: isMobileMenuOpen ? 1 : 0,
              x: isMobileMenuOpen ? 0 : -10,
            }}
            transition={{ delay: navItems.length * 0.05, duration: 0.2 }}
            className="inline-flex items-center justify-center gap-2 bg-gradient-gold text-primary-foreground px-5 py-3 rounded-full font-body font-medium"
          >
            <Phone className="w-4 h-4" />
            Book Now
          </motion.a>
        </nav>
      </motion.div>
    </motion.header>
  );
};

export default Header;
