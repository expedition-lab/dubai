import { motion } from "framer-motion";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const faqs = [
  {
    question: "What's included in the package?",
    answer: "Your experience includes return flights from Mauritius, 5 nights hotel accommodation, private airport transfers, curated excursions including Sky Views, Palm Jumeirah, and a full-day Abu Dhabi tour. Specific inclusions vary by package tier."
  },
  {
    question: "How do I secure my booking?",
    answer: "Simply reach out via WhatsApp to confirm availability. You'll receive a detailed itinerary and invoice, and your booking is confirmed once payment is received and all reservations are secured."
  },
  {
    question: "What is the cancellation policy?",
    answer: "We offer flexible cancellation with refunds based on timing: 70% refund for cancellations 30+ days before departure, scaling down closer to the travel date. Full details are provided at booking."
  },
  {
    question: "Are flights and hotels guaranteed?",
    answer: "All bookings are subject to availability. Once confirmed, you'll receive official documentation for your flights, accommodation, and all included experiences."
  },
  {
    question: "Do I need a visa for Dubai?",
    answer: "Mauritius passport holders typically receive visa on arrival. However, it's your responsibility to ensure valid travel documentation. We're happy to provide guidance during the booking process."
  },
  {
    question: "Is travel insurance included?",
    answer: "Travel insurance is strongly recommended for all travelers. We can advise on suitable options during your booking consultation."
  },
];

const FAQSection = () => {
  return (
    <section className="py-32 px-6 bg-charcoal relative overflow-hidden">
      {/* Subtle decorative element */}
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-gold/20 to-transparent" />
      
      <div className="max-w-3xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <p className="font-body text-gold uppercase tracking-[0.3em] text-sm mb-6">
            Common Questions
          </p>
          <h2 className="font-display text-4xl md:text-5xl text-foreground">
            Before You <span className="text-gradient-gold italic">Travel</span>
          </h2>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          <Accordion type="single" collapsible className="space-y-4">
            {faqs.map((faq, index) => (
              <AccordionItem 
                key={index} 
                value={`item-${index}`}
                className="border-none bg-charcoal-deep/50 rounded-2xl px-6 luxury-border hover:border-gold/30 transition-colors duration-300"
              >
                <AccordionTrigger className="font-display text-lg text-foreground hover:text-gold hover:no-underline py-6 [&[data-state=open]]:text-gold">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="font-body text-muted-foreground leading-relaxed pb-6">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </motion.div>
      </div>
    </section>
  );
};

export default FAQSection;
