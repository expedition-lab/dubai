import { motion } from "framer-motion";
import marinaImg from "@/assets/marina.jpg";
import mosqueImg from "@/assets/mosque.jpg";
import palmImg from "@/assets/palm.jpg";

const highlights = [
  {
    title: "Dubai Marina",
    subtitle: "JBR Walk & Night Life",
    image: marinaImg,
  },
  {
    title: "Sheikh Zayed Mosque",
    subtitle: "Abu Dhabi Heritage",
    image: mosqueImg,
  },
  {
    title: "Palm Jumeirah",
    subtitle: "The View at The Palm",
    image: palmImg,
  },
];

const HighlightsSection = () => {
  return (
    <section className="py-32 px-6 bg-gradient-dark">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-20"
        >
          <p className="font-body text-gold uppercase tracking-[0.3em] text-sm mb-4">
            Iconic Destinations
          </p>
          <h2 className="font-display text-4xl md:text-5xl lg:text-6xl text-foreground">
            Experience the <span className="text-gradient-gold italic">Extraordinary</span>
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 lg:gap-10">
          {highlights.map((item, index) => (
            <motion.div
              key={item.title}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: index * 0.15 }}
              whileHover={{ y: -12, transition: { duration: 0.4 } }}
              className="group relative aspect-[3/4] rounded-3xl overflow-hidden"
            >
              {/* Elegant frame border */}
              <div className="absolute inset-0 rounded-3xl border border-gold/20 group-hover:border-gold/40 transition-colors duration-500 z-20 pointer-events-none" />
              <div className="absolute inset-2 rounded-2xl border border-gold/10 group-hover:border-gold/20 transition-colors duration-500 z-20 pointer-events-none" />
              
              <img
                src={item.image}
                alt={item.title}
                className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
              />
              
              {/* Gradient overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-charcoal-deep via-charcoal-deep/30 to-transparent opacity-80 group-hover:opacity-90 transition-opacity duration-500" />
              
              {/* Content */}
              <div className="absolute bottom-0 left-0 right-0 p-8">
                <p className="font-body text-gold text-sm uppercase tracking-wider mb-3 opacity-80 group-hover:opacity-100 transition-opacity duration-300">
                  {item.subtitle}
                </p>
                <h3 className="font-display text-2xl md:text-3xl text-foreground group-hover:text-gradient-gold transition-all duration-300">
                  {item.title}
                </h3>
              </div>

              {/* Hover shine effect */}
              <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-700 pointer-events-none">
                <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-gold/5 to-transparent" />
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default HighlightsSection;
