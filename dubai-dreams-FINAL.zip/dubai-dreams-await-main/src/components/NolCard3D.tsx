import { useState } from "react";
import { motion } from "framer-motion";
import nolCardImg from "@/assets/nol-card.jpg";

const NolCard3D = () => {
  const [isFlipped, setIsFlipped] = useState(false);

  return (
    <div className="flex flex-col items-center gap-6">
      <p className="font-body text-muted-foreground text-sm uppercase tracking-[0.2em]">
        Tap to flip
      </p>

      <div
        className="relative w-[320px] h-[200px] cursor-pointer"
        style={{ perspective: "1000px" }}
        onClick={() => setIsFlipped(!isFlipped)}
      >
        <motion.div
          animate={{ rotateY: isFlipped ? 180 : 0 }}
          transition={{ duration: 0.8, ease: [0.23, 1, 0.32, 1] }}
          style={{ transformStyle: "preserve-3d" }}
          className="relative w-full h-full"
        >
          {/* Front */}
          <div
            className="absolute inset-0 rounded-2xl overflow-hidden shadow-elegant"
            style={{ backfaceVisibility: "hidden" }}
          >
            <img
              src={nolCardImg}
              alt="Dubai NOL Metro Card"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 rounded-2xl ring-1 ring-gold/20" />
          </div>

          {/* Back */}
          <div
            className="absolute inset-0 rounded-2xl overflow-hidden bg-card luxury-border shadow-elegant flex flex-col items-center justify-center p-6 text-center"
            style={{ backfaceVisibility: "hidden", transform: "rotateY(180deg)" }}
          >
            <span className="font-display text-2xl text-gradient-gold mb-3">NOL Card</span>
            <p className="font-body text-muted-foreground text-sm leading-relaxed">
              Preloaded metro card for seamless travel across Dubai's metro, tram & bus network.
            </p>
            <div className="mt-4 px-4 py-1.5 rounded-full bg-gold/10 luxury-border">
              <span className="font-body text-gold text-xs font-medium">Included in Package</span>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default NolCard3D;
