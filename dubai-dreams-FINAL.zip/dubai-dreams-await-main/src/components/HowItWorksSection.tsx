import { motion } from "framer-motion";
import { MessageCircle, FileText, CreditCard, CheckCircle } from "lucide-react";

const steps = [
  {
    number: "01",
    icon: MessageCircle,
    title: "Inquire",
    description: "Reach out via WhatsApp to discuss availability and preferences"
  },
  {
    number: "02",
    icon: FileText,
    title: "Review",
    description: "Receive your personalized itinerary and transparent pricing"
  },
  {
    number: "03",
    icon: CreditCard,
    title: "Confirm",
    description: "Secure your booking with payment and receive confirmation"
  },
  {
    number: "04",
    icon: CheckCircle,
    title: "Travel",
    description: "Enjoy your Dubai experience with full support throughout"
  },
];

const HowItWorksSection = () => {
  return (
    <section className="py-32 px-6 bg-charcoal relative overflow-hidden">
      {/* Decorative line */}
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-gold/20 to-transparent" />
      
      <div className="max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-20"
        >
          <p className="font-body text-gold uppercase tracking-[0.3em] text-sm mb-6">
            Simple Process
          </p>
          <h2 className="font-display text-4xl md:text-5xl text-foreground">
            How It <span className="text-gradient-gold italic">Works</span>
          </h2>
        </motion.div>

        <div className="relative">
          {/* Connection line - hidden on mobile */}
          <div className="hidden md:block absolute top-12 left-[10%] right-[10%] h-px bg-gradient-to-r from-gold/0 via-gold/30 to-gold/0" />
          
          <div className="grid md:grid-cols-4 gap-8 md:gap-4">
            {steps.map((step, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.15 }}
                className="text-center relative"
              >
                {/* Step number badge */}
                <div className="relative inline-flex mb-6">
                  <span className="w-24 h-24 rounded-full bg-charcoal-deep border border-gold/20 flex items-center justify-center relative z-10">
                    <step.icon className="w-8 h-8 text-gold" />
                  </span>
                  <span className="absolute -top-2 -right-2 font-display text-xs text-gold/60">
                    {step.number}
                  </span>
                </div>
                
                <h3 className="font-display text-xl text-foreground mb-3">
                  {step.title}
                </h3>
                <p className="font-body text-sm text-muted-foreground leading-relaxed max-w-[200px] mx-auto">
                  {step.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default HowItWorksSection;
