import { motion } from "framer-motion";
import { Check, Plane, Hotel, Bus, Ticket, Wifi, CreditCard, Shield, Headphones } from "lucide-react";
import skylineImg from "@/assets/dubai-skyline.jpg";
import NolCard3D from "./NolCard3D";

const inclusions = [
  { icon: Plane, text: "Return flight (Mauritius ↔ Dubai)" },
  { icon: Hotel, text: "6 Days / 5 Nights at Le Suite Hotel 4★" },
  { icon: Bus, text: "Daily transport during excursions" },
  { icon: Ticket, text: "Sky Views + Glass Slide Ticket" },
  { icon: Ticket, text: "View at the Palm Ticket" },
  { icon: Ticket, text: "Abu Dhabi Full Day Tour" },
  { icon: Wifi, text: "Dubai SIM (7-Day Data Plan)" },
  { icon: CreditCard, text: "Nol Metro Card (Preloaded)" },
  { icon: Shield, text: "Travel Insurance Included" },
  { icon: Headphones, text: "24/7 WhatsApp Support" },
];

const InclusionsSection = () => {
  return (
    <section className="relative py-24 overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <img
          src={skylineImg}
          alt="Dubai Skyline"
          className="w-full h-full object-cover opacity-20"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-background via-background/95 to-background" />
      </div>

      <div className="relative z-10 max-w-6xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <p className="font-body text-gold uppercase tracking-[0.3em] text-sm mb-4">
            Complete Package
          </p>
          <h2 className="font-display text-4xl md:text-5xl lg:text-6xl text-foreground">
            What's <span className="text-gradient-gold italic">Included</span>
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 lg:gap-6">
          {inclusions.map((item, index) => (
            <motion.div
              key={item.text}
              initial={{ opacity: 0, x: index % 2 === 0 ? -20 : 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.05 }}
              className="flex items-center gap-4 p-5 rounded-xl bg-card/50 backdrop-blur-sm luxury-border group hover:bg-card transition-colors duration-300"
            >
              <div className="flex-shrink-0 w-12 h-12 rounded-full bg-gold/10 flex items-center justify-center group-hover:bg-gold/20 transition-colors">
                <item.icon className="w-5 h-5 text-gold" />
              </div>
              <span className="font-body text-foreground text-base md:text-lg">
                {item.text}
              </span>
              <Check className="w-5 h-5 text-gold ml-auto flex-shrink-0" />
            </motion.div>
          ))}
        </div>

        {/* NOL Card 3D Showcase */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="mt-16"
        >
          <NolCard3D />
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.5 }}
          className="mt-12 text-center"
        >
          <div className="inline-block px-6 py-3 rounded-full bg-gold/10 luxury-border">
            <p className="font-body text-gold">
              <span className="font-semibold">Optional:</span> Palm Beach Villa Upgrade Available
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default InclusionsSection;
