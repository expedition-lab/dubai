import { motion } from "framer-motion";
import { Shield, FileCheck, MessageCircle, Eye } from "lucide-react";

const trustPoints = [
  { icon: FileCheck, text: "Official booking confirmation" },
  { icon: Shield, text: "Secure payment & invoicing" },
  { icon: MessageCircle, text: "Dedicated WhatsApp support" },
  { icon: Eye, text: "Full transparency, no hidden fees" },
];

const TrustSection = () => {
  return (
    <section className="py-24 px-6 bg-charcoal-deep relative overflow-hidden">
      <div className="max-w-5xl mx-auto">
        <div className="grid md:grid-cols-2 gap-16 items-center">
          {/* Operator Info */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <p className="font-body text-gold/80 uppercase tracking-[0.2em] text-xs mb-4">
              Operated By
            </p>
            <h3 className="font-display text-2xl md:text-3xl text-foreground mb-4">
              BlueXpedition <span className="text-gradient-gold">Mauritius</span>
            </h3>
            <p className="font-body text-muted-foreground leading-relaxed mb-6">
              A Mauritius-based travel provider specializing in premium experiences. 
              Professional assistance from departure to return.
            </p>
            <div className="flex items-center gap-6 text-sm text-muted-foreground">
              <span className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-gold" />
                Based in Mauritius
              </span>
              <span className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-gold" />
                Premium Service
              </span>
            </div>
          </motion.div>

          {/* Trust Guarantees */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="bg-charcoal/30 rounded-3xl p-8 luxury-border"
          >
            <p className="font-body text-gold/80 uppercase tracking-[0.2em] text-xs mb-6">
              Booking Guarantee
            </p>
            <div className="grid grid-cols-2 gap-4">
              {trustPoints.map((point, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 10 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.4, delay: 0.3 + index * 0.1 }}
                  className="flex items-center gap-3"
                >
                  <span className="w-8 h-8 rounded-lg bg-gold/10 flex items-center justify-center flex-shrink-0">
                    <point.icon className="w-4 h-4 text-gold" />
                  </span>
                  <span className="font-body text-sm text-foreground/80">
                    {point.text}
                  </span>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default TrustSection;
