import { motion } from "framer-motion";
import { Star, Quote } from "lucide-react";

const testimonials = [
  {
    name: "Priya Ramnarain",
    location: "Quatre Bornes, Mauritius",
    text: "BlueXpedition made everything seamless — from the airport pickup in Dubai to the Abu Dhabi tour. The hotel was stunning and the Sky Views experience was absolutely breathtaking. Already recommending to all my friends!",
    rating: 5,
    date: "January 2025",
  },
  {
    name: "Kevin & Sandra Morel",
    location: "Curepipe, Mauritius",
    text: "We were a bit nervous booking with a local agency but BlueXpedition delivered beyond expectations. Communication was excellent on WhatsApp throughout. The group was small and intimate — exactly as advertised.",
    rating: 5,
    date: "December 2024",
  },
  {
    name: "Anisha Dookee",
    location: "Rose Hill, Mauritius",
    text: "First time traveling outside Mauritius and I couldn't have asked for a better experience. The itinerary was perfectly planned, nothing felt rushed. Palm Jumeirah at sunset is something I'll never forget.",
    rating: 5,
    date: "November 2024",
  },
];

const TestimonialsSection = () => {
  return (
    <section className="py-32 px-6 bg-charcoal relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-gold/20 to-transparent" />

      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-20"
        >
          <p className="font-body text-gold uppercase tracking-[0.3em] text-sm mb-4">
            Traveler Stories
          </p>
          <h2 className="font-display text-4xl md:text-5xl text-foreground">
            Real <span className="text-gradient-gold italic">Experiences</span>
          </h2>
          <div className="divider-gold max-w-xs mx-auto mt-8" />
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((t, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.15 }}
              className="relative bg-charcoal-deep rounded-3xl p-8 luxury-border group hover:border-gold/30 transition-colors duration-500"
            >
              <Quote className="w-8 h-8 text-gold/30 mb-6" />

              <div className="flex gap-1 mb-4">
                {[...Array(t.rating)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 text-gold fill-gold" />
                ))}
              </div>

              <p className="font-body text-foreground/80 leading-relaxed mb-8 text-sm">
                "{t.text}"
              </p>

              <div className="border-t border-border pt-5">
                <p className="font-display text-foreground text-base">{t.name}</p>
                <p className="font-body text-muted-foreground text-xs mt-1">
                  {t.location} · {t.date}
                </p>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.5 }}
          className="text-center mt-14"
        >
          <p className="font-body text-muted-foreground text-sm">
            ⭐ Average rating:{" "}
            <span className="text-gold font-semibold">5.0 / 5.0</span> across
            all past travelers
          </p>
        </motion.div>
      </div>
    </section>
  );
};

export default TestimonialsSection;
