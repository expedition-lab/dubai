import { motion } from "framer-motion";
import { MapPin, Star, Waves, Building2, Train } from "lucide-react";

const hotels = [
  {
    id: 1,
    name: "Hilton Garden Inn Dubai Deira",
    tier: "Premium",
    address: "Riggat Al Buteen, Deira, Dubai",
    nearbyHighlights: ["Dubai Gold & Spice Souks", "Dubai Creek & Abra boats", "Al Ghurair City Mall"],
    transport: "Union Metro Station ~5 min walk",
    description:
      "Premium comfort in the heart of historic Deira — close to the iconic souks, Dubai Creek and easy metro access across the entire city.",
    icon: Waves,
    accent: "from-gold to-gold-dark",
  },
  {
    id: 2,
    name: "Hampton by Hilton Dubai Airport",
    tier: "City Centre",
    address: "Casablanca Road, Garhoud, Dubai",
    nearbyHighlights: ["Dubai International Airport", "Dubai Festival City Mall", "Dubai Creek Golf Club"],
    transport: "Airport Terminal 1 Metro ~2 min walk",
    description:
      "Smart, modern hotel just minutes from the airport with easy metro access to Downtown, the Burj Khalifa and all major attractions.",
    icon: Building2,
    accent: "from-gold to-gold-dark",
  },
  {
    id: 3,
    name: "Ibis World Trade Centre",
    tier: "Smart Value",
    address: "Exhibition Street, 9544, Dubai",
    nearbyHighlights: ["World Trade Centre", "Metro access to all Dubai", "Central district location"],
    transport: "World Trade Centre Metro — walking distance",
    description:
      "Budget-smart hotel in the heart of Dubai with direct metro access to malls, beaches and attractions.",
    icon: Train,
    accent: "from-gold to-gold-dark",
  },
];

const HotelOptionsSection = () => {
  return (
    <section className="py-32 px-6 bg-background relative overflow-hidden">
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-0 left-1/3 w-px h-full bg-gradient-to-b from-transparent via-gold/10 to-transparent" />
        <div className="absolute top-0 right-1/3 w-px h-full bg-gradient-to-b from-transparent via-gold/10 to-transparent" />
      </div>

      <div className="max-w-6xl mx-auto relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-20"
        >
          <p className="font-body text-gold uppercase tracking-[0.3em] text-sm mb-4">
            Where You'll Stay
          </p>
          <h2 className="font-display text-4xl md:text-5xl lg:text-6xl text-foreground">
            Your <span className="text-gradient-gold italic">Hotels</span>
          </h2>
          <p className="font-body text-muted-foreground mt-6 max-w-2xl mx-auto">
            Handpicked accommodations across Dubai's most iconic districts — each chosen for location, comfort and convenience.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-6 lg:gap-8">
          {hotels.map((hotel, index) => (
            <motion.div
              key={hotel.id}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7, delay: index * 0.15 }}
              whileHover={{ y: -8 }}
              className="group relative bg-card rounded-3xl luxury-border shadow-card hover:shadow-elegant transition-all duration-500 overflow-hidden"
            >
              <div className="absolute top-5 right-5 z-10">
                <span className="font-body text-xs uppercase tracking-wider bg-gold/15 text-gold px-3 py-1.5 rounded-full border border-gold/30">
                  {hotel.tier}
                </span>
              </div>
              <div className={`h-1 w-full bg-gradient-to-r ${hotel.accent}`} />
              <div className="p-8">
                <div className="w-14 h-14 rounded-2xl bg-gold/10 group-hover:bg-gold/20 flex items-center justify-center mb-6 transition-colors duration-300">
                  <hotel.icon className="w-7 h-7 text-gold" />
                </div>
                <h3 className="font-display text-2xl text-foreground mb-2">{hotel.name}</h3>
                <div className="flex items-center gap-2 mb-4">
                  <MapPin className="w-3.5 h-3.5 text-gold/60 flex-shrink-0" />
                  <p className="font-body text-muted-foreground text-sm">{hotel.address}</p>
                </div>
                <p className="font-body text-muted-foreground text-sm leading-relaxed mb-6">{hotel.description}</p>
                <div className="divider-gold mb-6 opacity-40" />
                <div className="mb-5">
                  <p className="font-body text-gold text-xs uppercase tracking-wider mb-3 flex items-center gap-2">
                    <Star className="w-3 h-3" /> Nearby
                  </p>
                  <ul className="space-y-2">
                    {hotel.nearbyHighlights.map((item) => (
                      <li key={item} className="font-body text-sm text-muted-foreground flex items-center gap-2.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-gold/50 flex-shrink-0" />
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="flex items-start gap-2.5 bg-charcoal/50 rounded-xl p-3.5">
                  <Train className="w-4 h-4 text-gold/70 flex-shrink-0 mt-0.5" />
                  <p className="font-body text-xs text-muted-foreground">{hotel.transport}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default HotelOptionsSection;
