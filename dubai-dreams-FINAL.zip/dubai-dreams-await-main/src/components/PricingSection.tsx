import { motion } from "framer-motion";
import { Check, Plane, Building2, Car, Camera, Users, Calendar } from "lucide-react";

const includedItems = [
{ icon: Plane, text: "Return flights Mauritius – Dubai" },
{ icon: Building2, text: "5 nights hotel accommodation" },
{ icon: Car, text: "Private airport transfers & transport" },
{ icon: Camera, text: "Sky Views + Palm Jumeirah View" },
{ icon: Users, text: "Abu Dhabi full-day tour" }];


const PricingSection = () => {
  return (
    <section className="py-32 px-6 bg-background relative overflow-hidden">
      {/* Subtle decorative elements */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/4 -left-32 w-64 h-64 bg-gold/5 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 -right-32 w-64 h-64 bg-gold/5 rounded-full blur-3xl" />
      </div>

      <div className="max-w-5xl mx-auto relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-20">

          <p className="font-body text-gold uppercase tracking-[0.3em] text-sm mb-4">
            Your Investment
          </p>
          <h2 className="font-display text-4xl md:text-5xl lg:text-6xl text-foreground">
            Complete <span className="text-gradient-gold italic">Package</span>
          </h2>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8 lg:gap-12">
          {/* Price Card */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="relative group">

            <div className="absolute -inset-0.5 bg-gradient-gold rounded-3xl opacity-20 group-hover:opacity-30 blur transition-opacity duration-500" />
            <div className="relative bg-charcoal rounded-3xl p-8 md:p-10 luxury-border h-full">
              {/* Badge */}
              <div className="inline-flex items-center gap-2 bg-gold/10 rounded-full px-4 py-1.5 mb-8">
                <span className="w-2 h-2 rounded-full bg-gold animate-pulse" />
                <span className="font-body text-gold text-sm">Limited availability</span>
              </div>

              <div className="mb-8">
                <p className="font-body text-muted-foreground text-sm mb-2">Starting from</p>
                <div className="flex items-baseline gap-2">
                  <span className="font-display text-5xl md:text-6xl lg:text-7xl text-gradient-gold">
                    Rs 95,000
                  </span>
                </div>
                <p className="font-body text-muted-foreground mt-2">
                  per person • twin sharing
                </p>
              </div>

              <div className="divider-gold mb-8" />

              <div className="space-y-4 mb-8">
                <div className="flex items-center justify-between">
                  <span className="font-body text-muted-foreground">Duration</span>
                  <span className="font-body text-foreground">6 Days / 5 Nights</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="font-body text-muted-foreground">Departure</span>
                  <span className="font-body text-foreground">Mauritius</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="font-body text-muted-foreground">Group size</span>
                  <span className="font-body text-foreground">Max 12 guests</span>
                </div>
              </div>

              {/* Departure date */}
              <div className="flex items-center gap-2 mb-5 bg-gold/5 rounded-xl px-4 py-3 border border-gold/20">
                <Calendar className="w-4 h-4 text-gold flex-shrink-0" />
                <span className="font-body text-sm text-foreground">
                  Next departure: <span className="text-gold font-semibold">15 May 2025</span> — <span className="text-amber-400">Only 4 spots left</span>
                </span>
              </div>

              <a
                href="#booking-form"
                className="w-full inline-flex items-center justify-center gap-3 bg-gradient-gold text-primary-foreground px-8 py-4 rounded-full font-body font-semibold text-lg shadow-gold hover:shadow-elegant transition-all duration-500 hover:scale-[1.02]">

                Reserve Your Spot
              </a>

              <p className="font-body text-muted-foreground text-xs text-center mt-4">
                Free cancellation up to 30 days before departure
              </p>
            </div>
          </motion.div>

          {/* Inclusions Card */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="bg-charcoal/50 rounded-3xl p-8 md:p-10 luxury-border">

            <h3 className="font-display text-2xl text-foreground mb-8">
              What's Included
            </h3>

            <ul className="space-y-5">
              {includedItems.map((item, index) =>
              <motion.li
                key={item.text}
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: 0.3 + index * 0.1 }}
                className="flex items-start gap-4 group">

                  <span className="flex-shrink-0 w-10 h-10 rounded-xl bg-gold/10 flex items-center justify-center group-hover:bg-gold/20 transition-colors duration-300">
                    <item.icon className="w-5 h-5 text-gold" />
                  </span>
                  <span className="font-body text-foreground pt-2">{item.text}</span>
                </motion.li>
              )}
            </ul>

            <div className="mt-10 pt-8 border-t border-border">
              <div className="flex items-center gap-3">
                <Check className="w-5 h-5 text-gold" />
                <span className="font-body text-muted-foreground text-sm">
                  All taxes & service charges included
                </span>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>);

};

export default PricingSection;