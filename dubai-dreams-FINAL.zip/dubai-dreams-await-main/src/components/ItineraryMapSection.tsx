import { motion } from "framer-motion";
import { MapPin, Hotel } from "lucide-react";
import { useState } from "react";

const locations = [
  { id: 1, name: "Dubai Marina", day: "Day 1", description: "JBR Walk & Night Life" },
  { id: 2, name: "Downtown Dubai", day: "Day 2", description: "Sky Views & Dubai Mall" },
  { id: 3, name: "Palm Jumeirah", day: "Day 3", description: "The View at The Palm" },
  { id: 4, name: "Abu Dhabi", day: "Day 4", description: "Sheikh Zayed Mosque" },
];

const hotels = [
  { id: "h1", name: "Hilton Garden Inn Dubai Deira", label: "Premium", coords: "25.0782,55.1347" },
  { id: "h2", name: "Hampton by Hilton Dubai Airport ", label: "City Centre", coords: "25.1865,55.2618" },
  { id: "h3", name: "Ibis World Trade Centre", label: "Smart Value", coords: "25.2228,55.2858" },
];

const ItineraryMapSection = () => {
  const [activeLocation, setActiveLocation] = useState<number | null>(null);

  return (
    <section className="py-32 px-6 bg-charcoal-deep relative overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-0 left-0 w-96 h-96 bg-gold rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2" />
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-gold rounded-full blur-3xl translate-x-1/2 translate-y-1/2" />
      </div>

      <div className="max-w-6xl mx-auto relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <p className="font-body text-gold uppercase tracking-[0.3em] text-sm mb-4">
            Your Route
          </p>
          <h2 className="font-display text-4xl md:text-5xl lg:text-6xl text-foreground">
            The <span className="text-gradient-gold italic">Journey</span>
          </h2>
        </motion.div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Map */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 1 }}
            className="lg:col-span-2 relative aspect-[4/3] lg:aspect-[16/10] rounded-3xl overflow-hidden luxury-border"
          >
            {/* Google Maps Embed with hotel markers */}
            <iframe
              src={`https://www.google.com/maps/embed?pb=!1m52!1m12!1m3!1d464961.4684898375!2d54.55726707968751!3d24.69093099999999!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!4m37!3e0!4m5!1s0x3e5f43348a67e24b%3A0xff45e502e1ceb7e2!2sDubai%20Marina%2C%20Dubai%2C%20UAE!3m2!1d25.0805182!2d55.1403274!4m5!1s0x3e5f682829c85c07%3A0xa5eda9fb3c93b69d!2sDowntown%20Dubai%2C%20Dubai%2C%20UAE!3m2!1d25.1971608!2d55.2743764!4m5!1s0x3e5f6a5715410e21%3A0xb7079d5e91dc7e80!2sPalm%20Jumeirah%2C%20Dubai%2C%20UAE!3m2!1d25.1124384!2d55.1389877!4m5!1s0x3e5e440f723ef2b9%3A0xc3c9149035e0eb!2sSheikh%20Zayed%20Grand%20Mosque%2C%20Abu%20Dhabi%2C%20UAE!3m2!1d24.4128498!2d54.4749143!4m5!1s0x3e5f43348a67e24b%3A0xff45e502e1ceb7e2!2sDubai%20Marina!3m2!1d25.0805182!2d55.1403274!4m5!1s0x3e5f5e40be006897%3A0xd756da10e53f2dd5!2sDubai%20International%20Airport%2C%20Dubai%2C%20UAE!3m2!1d25.2531745!2d55.3656728!5e0!3m2!1sen!2s!4v1707000000000!5m2!1sen!2s`}
              width="100%"
              height="100%"
              style={{ border: 0, filter: "grayscale(100%) invert(92%) contrast(90%) brightness(80%) sepia(30%) hue-rotate(10deg)" }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              title="Dubai Itinerary Map"
              className="absolute inset-0"
            />
            
            {/* Overlay gradient for blend */}
            <div className="absolute inset-0 pointer-events-none bg-gradient-to-t from-charcoal-deep/30 via-transparent to-charcoal-deep/20" />
            
            {/* Corner accents */}
            <div className="absolute top-4 left-4 w-8 h-8 border-l-2 border-t-2 border-gold/40 rounded-tl-lg" />
            <div className="absolute top-4 right-4 w-8 h-8 border-r-2 border-t-2 border-gold/40 rounded-tr-lg" />
            <div className="absolute bottom-4 left-4 w-8 h-8 border-l-2 border-b-2 border-gold/40 rounded-bl-lg" />
            <div className="absolute bottom-4 right-4 w-8 h-8 border-r-2 border-b-2 border-gold/40 rounded-br-lg" />
          </motion.div>

          {/* Locations List */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="flex flex-col justify-center gap-4"
          >
          {locations.map((location, index) => (
              <motion.div
                key={location.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: 0.4 + index * 0.1 }}
                whileHover={{ x: 8 }}
                onClick={() => setActiveLocation(activeLocation === location.id ? null : location.id)}
                className={`group rounded-2xl p-5 luxury-border transition-all duration-300 cursor-pointer ${
                  activeLocation === location.id 
                    ? "bg-gold/10 border-gold/60 scale-[1.02]" 
                    : "bg-charcoal/50 hover:border-gold/40"
                }`}
              >
                <div className="flex items-start gap-4">
                  <span className={`flex-shrink-0 w-10 h-10 rounded-xl flex items-center justify-center transition-colors duration-300 ${
                    activeLocation === location.id ? "bg-gold/30" : "bg-gold/10 group-hover:bg-gold/20"
                  }`}>
                    <MapPin className="w-5 h-5 text-gold" />
                  </span>
                  <div>
                    <p className="font-body text-gold text-xs uppercase tracking-wider mb-1">
                      {location.day}
                    </p>
                    <h3 className="font-display text-lg text-foreground mb-0.5">
                      {location.name}
                    </h3>
                    <p className="font-body text-muted-foreground text-sm">
                      {location.description}
                    </p>
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>

          {/* Hotel Legend */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.6 }}
            className="lg:col-span-3 mt-4"
          >
            <p className="font-body text-gold text-xs uppercase tracking-wider mb-4 flex items-center gap-2">
              <Hotel className="w-4 h-4" /> Your Hotels
            </p>
            <div className="grid sm:grid-cols-3 gap-3">
              {hotels.map((hotel) => (
                <div
                  key={hotel.id}
                  className="flex items-center gap-3 bg-charcoal/50 rounded-xl p-3 luxury-border"
                >
                  <span className="w-8 h-8 rounded-lg bg-gold/10 flex items-center justify-center flex-shrink-0">
                    <Hotel className="w-4 h-4 text-gold" />
                  </span>
                  <div>
                    <p className="font-body text-foreground text-sm">{hotel.name}</p>
                    <p className="font-body text-muted-foreground text-xs">{hotel.label}</p>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        </div>

        {/* Journey summary */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.5 }}
          className="mt-12 text-center"
        >
          <p className="font-body text-muted-foreground max-w-2xl mx-auto">
            From the gleaming towers of Dubai Marina to the majestic Sheikh Zayed Grand Mosque in Abu Dhabi — 
            your curated journey spans the finest destinations the Emirates has to offer.
          </p>
        </motion.div>
      </div>
    </section>
  );
};

export default ItineraryMapSection;
