import { motion } from "framer-motion";
import { useState } from "react";
import { Send, CheckCircle, Calendar, Users, User, Mail, Phone } from "lucide-react";

const DEPARTURE_DATE = "13 June 2025";
const SPOTS_LEFT = 8;

const InquiryFormSection = () => {
  const [submitted, setSubmitted] = useState(false);
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    guests: "1",
    message: "",
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e: React.MouseEvent) => {
    e.preventDefault();
    if (!form.name || !form.email || !form.phone) return;
    const msg = encodeURIComponent(
      `Hello BlueXpedition! I'd like to inquire about the Dubai Experience package.\n\nName: ${form.name}\nEmail: ${form.email}\nPhone: ${form.phone}\nGuests: ${form.guests}\n${form.message ? `Message: ${form.message}` : ""}`
    );
    window.open(`https://wa.me/23054960101?text=${msg}`, "_blank");
    setSubmitted(true);
  };

  return (
    <section id="booking-form" className="py-32 px-6 bg-background relative overflow-hidden">
      <div className="absolute top-1/4 -right-32 w-96 h-96 bg-gold/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <p className="font-body text-gold uppercase tracking-[0.3em] text-sm mb-4">
            Reserve Your Spot
          </p>
          <h2 className="font-display text-4xl md:text-5xl text-foreground">
            Secure Your <span className="text-gradient-gold italic">Place</span>
          </h2>
          <div className="divider-gold max-w-xs mx-auto mt-8" />
        </motion.div>

        <div className="grid md:grid-cols-2 gap-12 items-start">
          {/* Left: Info panel */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <div className="bg-gradient-gold rounded-2xl p-6 mb-8">
              <div className="flex items-center gap-3 mb-2">
                <Calendar className="w-5 h-5 text-primary-foreground" />
                <span className="font-body text-primary-foreground font-semibold uppercase tracking-widest text-xs">
                  Next Departure
                </span>
              </div>
              <p className="font-display text-3xl text-primary-foreground">{DEPARTURE_DATE}</p>
              <p className="font-body text-primary-foreground/80 text-sm mt-1">6 Days · 5 Nights from Mauritius</p>
            </div>

            <div className="bg-charcoal rounded-2xl p-6 luxury-border mb-8">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <Users className="w-4 h-4 text-gold" />
                  <span className="font-body text-sm text-muted-foreground">Availability</span>
                </div>
                <span className="font-body text-xs text-gold bg-gold/10 px-3 py-1 rounded-full">
                  ⚠️ Only {SPOTS_LEFT} spots left
                </span>
              </div>
              <div className="w-full bg-charcoal-deep rounded-full h-2">
                <div
                  className="bg-gradient-gold h-2 rounded-full transition-all"
                  style={{ width: `${((12 - SPOTS_LEFT) / 12) * 100}%` }}
                />
              </div>
              <p className="font-body text-xs text-muted-foreground mt-2">{12 - SPOTS_LEFT} of 12 spots filled</p>
            </div>

            <div className="bg-charcoal/50 rounded-2xl p-6 luxury-border">
              <p className="font-body text-gold text-xs uppercase tracking-widest mb-3">Cancellation Policy</p>
              <ul className="space-y-2">
                {[
                  "Free cancellation up to 30 days before departure",
                  "50% refund between 15–30 days before departure",
                  "No refund within 14 days of departure",
                  "Full deposit required to confirm your spot",
                ].map((p, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm text-muted-foreground font-body">
                    <CheckCircle className="w-4 h-4 text-gold/60 flex-shrink-0 mt-0.5" />
                    {p}
                  </li>
                ))}
              </ul>
            </div>
          </motion.div>

          {/* Right: Form */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="bg-charcoal rounded-3xl p-8 luxury-border"
          >
            {submitted ? (
              <div className="text-center py-16">
                <div className="w-20 h-20 rounded-full bg-gold/10 flex items-center justify-center mx-auto mb-6">
                  <CheckCircle className="w-10 h-10 text-gold" />
                </div>
                <h3 className="font-display text-2xl text-foreground mb-4">Message Sent!</h3>
                <p className="font-body text-muted-foreground">
                  Your WhatsApp should have opened. Our team will confirm your spot within 24 hours.
                </p>
              </div>
            ) : (
              <div className="space-y-5">
                <h3 className="font-display text-xl text-foreground mb-6">Your Details</h3>

                <div>
                  <label className="font-body text-xs text-muted-foreground uppercase tracking-widest mb-2 block">Full Name *</label>
                  <div className="relative">
                    <User className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <input
                      type="text"
                      name="name"
                      value={form.name}
                      onChange={handleChange}
                      placeholder="Your full name"
                      className="w-full bg-charcoal-deep border border-border rounded-xl pl-11 pr-4 py-3 font-body text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:border-gold/50 transition-colors text-sm"
                    />
                  </div>
                </div>

                <div>
                  <label className="font-body text-xs text-muted-foreground uppercase tracking-widest mb-2 block">Email Address *</label>
                  <div className="relative">
                    <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <input
                      type="email"
                      name="email"
                      value={form.email}
                      onChange={handleChange}
                      placeholder="your@email.com"
                      className="w-full bg-charcoal-deep border border-border rounded-xl pl-11 pr-4 py-3 font-body text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:border-gold/50 transition-colors text-sm"
                    />
                  </div>
                </div>

                <div>
                  <label className="font-body text-xs text-muted-foreground uppercase tracking-widest mb-2 block">Phone / WhatsApp *</label>
                  <div className="relative">
                    <Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <input
                      type="tel"
                      name="phone"
                      value={form.phone}
                      onChange={handleChange}
                      placeholder="+230 5xxx xxxx"
                      className="w-full bg-charcoal-deep border border-border rounded-xl pl-11 pr-4 py-3 font-body text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:border-gold/50 transition-colors text-sm"
                    />
                  </div>
                </div>

                <div>
                  <label className="font-body text-xs text-muted-foreground uppercase tracking-widest mb-2 block">Number of Guests</label>
                  <select
                    name="guests"
                    value={form.guests}
                    onChange={handleChange}
                    className="w-full bg-charcoal-deep border border-border rounded-xl px-4 py-3 font-body text-foreground focus:outline-none focus:border-gold/50 transition-colors text-sm"
                  >
                    {[1, 2, 3, 4].map((n) => (
                      <option key={n} value={n}>
                        {n} {n === 1 ? "Person" : "People"} — Rs {(95000 * n).toLocaleString()}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="font-body text-xs text-muted-foreground uppercase tracking-widest mb-2 block">Any Questions? (optional)</label>
                  <textarea
                    name="message"
                    value={form.message}
                    onChange={handleChange}
                    placeholder="E.g. dietary requirements, room preferences..."
                    rows={3}
                    className="w-full bg-charcoal-deep border border-border rounded-xl px-4 py-3 font-body text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:border-gold/50 transition-colors text-sm resize-none"
                  />
                </div>

                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={handleSubmit}
                  className="w-full inline-flex items-center justify-center gap-3 bg-gradient-gold text-primary-foreground px-8 py-4 rounded-full font-body font-semibold text-lg shadow-gold hover:shadow-elegant transition-all duration-500 mt-2"
                >
                  <Send className="w-5 h-5" />
                  Send Inquiry via WhatsApp
                </motion.button>

                <p className="font-body text-muted-foreground text-xs text-center mt-3">
                  We respond within 24 hours. No spam, ever.
                </p>
              </div>
            )}
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default InquiryFormSection;
