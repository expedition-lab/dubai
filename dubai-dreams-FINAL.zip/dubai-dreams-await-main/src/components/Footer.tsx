import { Phone, Mail, MapPin, MessageCircle } from "lucide-react";
import { Link } from "react-router-dom";

const Footer = () => {
  return (
    <footer className="py-16 px-6 bg-charcoal-deep border-t border-border">
      <div className="max-w-6xl mx-auto">
        {/* Main Footer Content */}
        <div className="grid md:grid-cols-3 gap-12 mb-12">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-gradient-gold flex items-center justify-center">
                <span className="font-display text-primary-foreground font-bold">B</span>
              </div>
              <div>
                <span className="font-display text-lg text-foreground block">
                  BlueXpedition
                </span>
                <span className="font-body text-xs text-muted-foreground">
                  Mauritius
                </span>
              </div>
            </div>
            <p className="font-body text-muted-foreground text-sm leading-relaxed">
              Premium travel experiences from Mauritius to Dubai. Professional service, transparent bookings.
            </p>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-display text-foreground mb-4">Contact</h4>
            <div className="space-y-3">
              <a 
                href="tel:+23054960101" 
                className="flex items-center gap-3 text-muted-foreground hover:text-gold transition-colors text-sm"
              >
                <Phone className="w-4 h-4" />
                +230 5496 0101
              </a>
              <a 
                href="https://wa.me/23054960101" 
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center gap-3 text-muted-foreground hover:text-gold transition-colors text-sm"
              >
                <MessageCircle className="w-4 h-4" />
                WhatsApp
              </a>
              <a 
                href="mailto:booking@bluexpedition.com"
                className="flex items-center gap-3 text-muted-foreground hover:text-gold transition-colors text-sm"
              >
                <Mail className="w-4 h-4" />
                booking@bluexpedition.com
              </a>
              <span className="flex items-center gap-3 text-muted-foreground text-sm">
                <MapPin className="w-4 h-4" />
                Based in Mauritius
              </span>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-display text-foreground mb-4">Information</h4>
            <div className="space-y-3">
              <Link 
                to="/terms" 
                className="block text-muted-foreground hover:text-gold transition-colors text-sm"
              >
                Terms & Conditions
              </Link>
              <a 
                href="#pricing" 
                className="block text-muted-foreground hover:text-gold transition-colors text-sm"
              >
                Pricing
              </a>
              <a 
                href="#itinerary" 
                className="block text-muted-foreground hover:text-gold transition-colors text-sm"
              >
                Itinerary
              </a>
            </div>
          </div>
        </div>

        <div className="divider-gold opacity-30" />

        {/* Bottom Notice */}
        <div className="mt-8 text-center">
          <p className="font-body text-muted-foreground text-xs leading-relaxed max-w-2xl mx-auto mb-4">
            BlueXpedition Mauritius is a Mauritius-based travel service provider. All packages are subject to availability and confirmation. 
            By booking, you agree to our Terms & Conditions.
          </p>
          <p className="font-body text-muted-foreground/60 text-xs">
            © {new Date().getFullYear()} BlueXpedition Mauritius. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
