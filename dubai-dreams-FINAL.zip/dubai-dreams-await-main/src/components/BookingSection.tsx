import { motion } from "framer-motion";
import { MessageCircle, MapPin, ArrowRight } from "lucide-react";

const BookingSection = () => {
  return (
    <section className="py-32 px-6 bg-gradient-dark relative overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] rounded-full border border-gold/5" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full border border-gold/10" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[400px] h-[400px] rounded-full border border-gold/15" />
      </div>

      <div className="max-w-4xl mx-auto text-center relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <p className="font-body text-gold uppercase tracking-[0.3em] text-sm mb-6">
            Limited Seats Available
          </p>
          <h2 className="font-display text-4xl md:text-5xl lg:text-6xl text-foreground mb-8">
            Ready for <span className="text-gradient-gold italic">Dubai?</span>
          </h2>
          <div className="divider-gold max-w-xs mx-auto mb-12" />
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="mb-16"
        >
          <p className="font-body text-muted-foreground text-lg max-w-xl mx-auto leading-relaxed">
            Join an intimate group of discerning travelers for an unforgettable journey through the Emirates.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-5 mb-16"
        >
          <motion.a
            href="https://wa.me/23054960101"
            target="_blank"
            rel="noopener noreferrer"
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.98 }}
            className="inline-flex items-center gap-3 bg-gradient-gold text-primary-foreground px-10 py-5 rounded-full font-body font-semibold text-lg shadow-gold hover:shadow-elegant transition-all duration-500 group"
          >
            <MessageCircle className="w-5 h-5" />
            Start a Conversation
            <ArrowRight className="w-5 h-5 opacity-0 -ml-2 group-hover:opacity-100 group-hover:ml-0 transition-all duration-300" />
          </motion.a>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="flex items-center justify-center gap-3 text-muted-foreground"
        >
          <MapPin className="w-4 h-4 text-gold" />
          <span className="font-body text-sm">
            Departing from Mauritius
          </span>
        </motion.div>
      </div>
    </section>
  );
};

export default BookingSection;
