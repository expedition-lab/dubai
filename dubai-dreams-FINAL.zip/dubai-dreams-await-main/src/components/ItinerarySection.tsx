import { motion } from "framer-motion";
import { Plane, Building2, Sunrise, Landmark, PlaneTakeoff } from "lucide-react";

const days = [
  {
    day: "01",
    title: "Arrival Dubai",
    icon: Plane,
    highlights: ["Flight Mauritius → Dubai", "Hotel Check-in", "Dubai Marina / JBR Walk", "Evening Dinner"],
  },
  {
    day: "02",
    title: "Downtown Skyline",
    icon: Building2,
    highlights: ["Sky Views Observatory", "Glass Slide Experience", "Dubai Mall", "Dubai Fountain Show"],
  },
  {
    day: "03",
    title: "Palm Experience",
    icon: Sunrise,
    highlights: ["The View at The Palm", "Palm Jumeirah Tour", "Free Shopping Time", "Evening City Vibes"],
  },
  {
    day: "04",
    title: "Abu Dhabi Tour",
    icon: Landmark,
    highlights: ["Sheikh Zayed Grand Mosque", "Ferrari World Photo Stop", "Abu Dhabi Sightseeing", "Return to Dubai"],
  },
  {
    day: "05",
    title: "Leisure & Shopping",
    icon: Sunrise,
    highlights: ["Breakfast at Hotel", "Free Morning for Shopping", "Optional: Dubai Marina Cruise", "Evening at leisure"],
  },
  {
    day: "06",
    title: "Departure",
    icon: PlaneTakeoff,
    highlights: ["Final Breakfast", "Last Minute Shopping", "Airport Transfer", "Dubai → Mauritius"],
  },
];

const ItinerarySection = () => {
  return (
    <section className="py-32 px-6 bg-background relative overflow-hidden">
      {/* Subtle background decoration */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-0 left-1/4 w-px h-full bg-gradient-to-b from-transparent via-gold/10 to-transparent" />
        <div className="absolute top-0 right-1/4 w-px h-full bg-gradient-to-b from-transparent via-gold/10 to-transparent" />
      </div>

      <div className="max-w-5xl mx-auto relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-24"
        >
          <p className="font-body text-gold uppercase tracking-[0.3em] text-sm mb-4">
            Your Journey
          </p>
          <h2 className="font-display text-4xl md:text-5xl lg:text-6xl text-foreground">
            Full <span className="text-gradient-gold italic">Itinerary</span>
          </h2>
        </motion.div>

        <div className="relative">
          {/* Timeline Line */}
          <div className="absolute left-8 md:left-1/2 top-0 bottom-0 w-px bg-gradient-to-b from-gold via-gold/50 to-transparent" />

          {days.map((item, index) => (
            <motion.div
              key={item.day}
              initial={{ opacity: 0, x: index % 2 === 0 ? -40 : 40 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: index * 0.1 }}
              className={`relative flex items-start gap-8 mb-16 md:mb-20 ${
                index % 2 === 0 ? "md:flex-row" : "md:flex-row-reverse"
              }`}
            >
              {/* Day Number Circle */}
              <motion.div 
                whileHover={{ scale: 1.1, rotate: 5 }}
                transition={{ duration: 0.3 }}
                className="absolute left-8 md:left-1/2 -translate-x-1/2 w-16 h-16 rounded-full bg-charcoal border-2 border-gold flex items-center justify-center z-10 shadow-gold cursor-pointer"
              >
                <item.icon className="w-6 h-6 text-gold" />
              </motion.div>

              {/* Content Card */}
              <div className={`ml-24 md:ml-0 md:w-[calc(50%-4rem)] ${index % 2 === 0 ? "md:text-right md:pr-8" : "md:text-left md:pl-8"}`}>
                <motion.div 
                  whileHover={{ y: -4 }}
                  transition={{ duration: 0.3 }}
                  className="bg-card rounded-3xl p-8 md:p-10 luxury-border shadow-card hover:shadow-elegant transition-shadow duration-500 group"
                >
                  <span className="font-display text-6xl text-gold/20 group-hover:text-gold/30 transition-colors duration-300">
                    {item.day}
                  </span>
                  <h3 className="font-display text-2xl md:text-3xl text-foreground -mt-2 mb-6">
                    {item.title}
                  </h3>
                  <ul className={`space-y-3 ${index % 2 === 0 ? "md:text-right" : "md:text-left"}`}>
                    {item.highlights.map((highlight) => (
                      <li key={highlight} className="font-body text-muted-foreground flex items-center gap-3 group-hover:text-foreground/80 transition-colors duration-300">
                        {index % 2 !== 0 && <span className="w-2 h-2 rounded-full bg-gold/50 group-hover:bg-gold transition-colors duration-300 flex-shrink-0" />}
                        {highlight}
                        {index % 2 === 0 && <span className="w-2 h-2 rounded-full bg-gold/50 group-hover:bg-gold transition-colors duration-300 flex-shrink-0 md:order-first md:ml-auto md:mr-0" />}
                      </li>
                    ))}
                  </ul>
                </motion.div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ItinerarySection;
