import Header from "@/components/Header";
import HeroSection from "@/components/HeroSection";
import HighlightsSection from "@/components/HighlightsSection";
import ExclusiveSection from "@/components/ExclusiveSection";
import ItinerarySection from "@/components/ItinerarySection";
import ItineraryMapSection from "@/components/ItineraryMapSection";
import HotelOptionsSection from "@/components/HotelOptionsSection";
import InclusionsSection from "@/components/InclusionsSection";
import PricingSection from "@/components/PricingSection";
import HowItWorksSection from "@/components/HowItWorksSection";
import TestimonialsSection from "@/components/TestimonialsSection";
import InquiryFormSection from "@/components/InquiryFormSection";
import FAQSection from "@/components/FAQSection";
import TrustSection from "@/components/TrustSection";
import BookingSection from "@/components/BookingSection";
import Footer from "@/components/Footer";
import FloatingCTA from "@/components/FloatingCTA";
import BackToTop from "@/components/BackToTop";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        <HeroSection />
        <section id="highlights">
          <HighlightsSection />
        </section>
        <ExclusiveSection />
        <section id="itinerary">
          <ItinerarySection />
        </section>
        <ItineraryMapSection />
        <HotelOptionsSection />
        <section id="inclusions">
          <InclusionsSection />
        </section>
        <section id="pricing">
          <PricingSection />
        </section>
        <HowItWorksSection />
        <TestimonialsSection />
        <InquiryFormSection />
        <FAQSection />
        <TrustSection />
        <BookingSection />
      </main>
      <Footer />
      <FloatingCTA />
      <BackToTop />
    </div>
  );
};

export default Index;
