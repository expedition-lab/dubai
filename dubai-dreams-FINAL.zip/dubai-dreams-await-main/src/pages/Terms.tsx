import { motion } from "framer-motion";
import { ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";

const Terms = () => {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 glass-dark border-b border-border/50">
        <div className="max-w-6xl mx-auto px-6 py-4">
          <Link 
            to="/" 
            className="inline-flex items-center gap-2 text-muted-foreground hover:text-gold transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            <span className="font-body text-sm">Back to Home</span>
          </Link>
        </div>
      </header>

      <main className="pt-32 pb-20 px-6">
        <div className="max-w-3xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="mb-16"
          >
            <p className="font-body text-gold uppercase tracking-[0.3em] text-sm mb-6">
              Legal
            </p>
            <h1 className="font-display text-4xl md:text-5xl text-foreground mb-4">
              Terms & <span className="text-gradient-gold italic">Conditions</span>
            </h1>
            <div className="divider-gold max-w-xs" />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="prose prose-invert max-w-none"
          >
            <p className="font-body text-muted-foreground leading-relaxed mb-8">
              By booking with BlueXpedition Mauritius, you agree to the following terms and conditions.
            </p>

            <Section title="1. Booking Confirmation">
              <p>Your booking is confirmed only after full payment is received and availability is confirmed for flights, hotel, and excursions. BlueXpedition reserves the right to decline any booking if availability is not confirmed.</p>
            </Section>

            <Section title="2. Payment Policy">
              <ul>
                <li>Full payment is required to confirm your reservation</li>
                <li>Seats are limited and allocated on a first-paid basis</li>
                <li>No booking is confirmed without payment</li>
              </ul>
            </Section>

            <Section title="3. Cancellation Policy">
              <p>If the traveler cancels after booking confirmation, the following charges apply:</p>
              <ul>
                <li>More than 30 days before departure: 70% refund</li>
                <li>15 to 30 days before departure: 50% refund</li>
                <li>7 to 14 days before departure: 25% refund</li>
                <li>Less than 7 days before departure: No refund</li>
              </ul>
            </Section>

            <Section title="4. Refund Policy">
              <p>Refunds are processed within 7 to 21 working days, subject to banking and supplier timelines. No refunds for no-shows, missed flights, late arrivals, or unused services.</p>
            </Section>

            <Section title="5. Flight Changes">
              <p>Flights are subject to airline schedule changes. BlueXpedition will assist with updated information but is not responsible for delays, cancellations, or rescheduling by airlines.</p>
            </Section>

            <Section title="6. Passport & Visa">
              <p>Travelers must ensure valid passport (minimum 6 months validity) and required documentation. BlueXpedition is not responsible for denied boarding or entry due to documentation issues.</p>
            </Section>

            <Section title="7. Responsibility Disclaimer">
              <p>BlueXpedition Mauritius acts as a travel organizer. We are not responsible for events outside our control including airline issues, immigration refusal, weather, accidents, lost luggage, or force majeure events. Travel insurance is recommended.</p>
            </Section>

            <Section title="8. Itinerary Changes">
              <p>The itinerary may be adjusted due to weather, traffic, venue availability, or unforeseen circumstances to ensure the best possible experience.</p>
            </Section>

            <Section title="9. Travel Insurance">
              <p>Travel insurance is strongly recommended. Details will be shared at booking confirmation if included in your package.</p>
            </Section>

            <Section title="10. Customer Conduct">
              <p>Travelers must respect local laws and regulations in Dubai/UAE. BlueXpedition is not responsible for penalties caused by misconduct or violations of UAE rules.</p>
            </Section>
          </motion.div>
        </div>
      </main>

      {/* Simple Footer */}
      <footer className="py-8 px-6 border-t border-border">
        <div className="max-w-3xl mx-auto text-center">
          <p className="font-body text-muted-foreground text-sm">
            © {new Date().getFullYear()} BlueXpedition Mauritius. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
};

const Section = ({ title, children }: { title: string; children: React.ReactNode }) => (
  <div className="mb-10">
    <h2 className="font-display text-xl text-foreground mb-4">{title}</h2>
    <div className="font-body text-muted-foreground leading-relaxed space-y-3">
      {children}
    </div>
  </div>
);

export default Terms;
