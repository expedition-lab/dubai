import { useCallback } from "react";

interface SmoothScrollOptions {
  offset?: number;
  duration?: number;
}

export const useSmoothScroll = (options: SmoothScrollOptions = {}) => {
  const { offset = 80, duration = 1000 } = options;

  const easeInOutCubic = (t: number): number => {
    return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
  };

  const scrollTo = useCallback(
    (targetId: string) => {
      const element = document.getElementById(targetId);
      if (!element) return;

      const targetPosition = element.getBoundingClientRect().top + window.scrollY - offset;
      const startPosition = window.scrollY;
      const distance = targetPosition - startPosition;
      let startTime: number | null = null;

      const animation = (currentTime: number) => {
        if (startTime === null) startTime = currentTime;
        const timeElapsed = currentTime - startTime;
        const progress = Math.min(timeElapsed / duration, 1);
        const easeProgress = easeInOutCubic(progress);

        window.scrollTo(0, startPosition + distance * easeProgress);

        if (timeElapsed < duration) {
          requestAnimationFrame(animation);
        }
      };

      requestAnimationFrame(animation);
    },
    [offset, duration]
  );

  const handleClick = useCallback(
    (e: React.MouseEvent<HTMLAnchorElement>, targetId: string) => {
      e.preventDefault();
      scrollTo(targetId);
      
      // Update URL hash without jumping
      window.history.pushState(null, "", `#${targetId}`);
    },
    [scrollTo]
  );

  return { scrollTo, handleClick };
};
