# Dubai Dreams Await — BlueXpedition Mauritius

A premium travel landing page for the Dubai Experience package by BlueXpedition Mauritius.

## Tech Stack

- React + TypeScript
- Vite
- Tailwind CSS
- Framer Motion
- shadcn/ui

## Getting Started

```bash
npm install
npm run dev
```

## Building for Production

```bash
npm run build
```
